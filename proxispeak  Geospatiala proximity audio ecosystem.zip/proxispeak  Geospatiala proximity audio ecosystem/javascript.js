```javascript
// ============================================
// PROXISPEAK LOGIN
// ============================================


function loginUser() {

    const username =
        document.getElementById("username").value.trim();

    const password =
        document.getElementById("password").value.trim();

    const message =
        document.getElementById("loginMessage");


    // Check empty fields

    if (username === "" || password === "") {

        message.style.color = "#f87171";

        message.innerText =
            "⚠️ Please enter username and password.";

        return;
    }


    // Demo authentication

    if (
        username === "admin" &&
        password === "1234"
    ) {

        localStorage.setItem(
            "proxiSpeakUser",
            username
        );

        message.style.color = "#4ade80";

        message.innerText =
            "✅ Login successful!";

        setTimeout(function() {

            window.location.href =
                "index.html";

        }, 700);

    }

    else {

        message.style.color = "#f87171";

        message.innerText =
            "❌ Invalid username or password.";

    }

}


// ============================================
// DEMO LOGIN
// ============================================

function demoLogin() {

    localStorage.setItem(
        "proxiSpeakUser",
        "Demo User"
    );


    window.location.href =
        "index.html";

}
```
