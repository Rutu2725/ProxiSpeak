`<script>

document.getElementById("loginButton").onclick = function () {

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const message = document.getElementById("message");

    if (username === "" || password === "") {

        message.style.color = "#f87171";
        message.innerText = "⚠️ Please enter username and password.";

        return;
    }

    // For prototype: any username and password
    message.style.color = "#4ade80";
    message.innerText = "✅ Login successful!";

    localStorage.setItem("proxiSpeakUser", username);

    // Redirect directly to index.html
    setTimeout(function () {

        window.location.href = "./index.html";

    }, 1000);

};


document.getElementById("demoButton").onclick = function () {

    localStorage.setItem("proxiSpeakUser", "Demo User");

    window.location.href = "./index.html";

};

</script>